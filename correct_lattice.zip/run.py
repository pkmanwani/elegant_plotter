#!/usr/bin/env python

# save_lattice.filename 6
execution_mode = 'serial'

lattice_file = """

"D1": DRIF,l=0.55
"D10": DRIF,l=0.5123
"D2": DRIF,l=0.1
"D3": DRIF,l=0.1
"D4": DRIF,l=1.025
"D5": DRIF,l=1.025
"D6": DRIF,l=0.1
"D7": DRIF,l=0.109
"D8": DRIF,l=2.431
"D9": DRIF,l=0.1
"M1": MARK,fitpoint=1
"Q1": QUAD,k1=4.6831,l=0.12
"Q2": QUAD,k1=29.2174,l=0.12
"Q3": QUAD,k1=-31,l=0.12
"Q4": QUAD,k1=-22.93873821325489,l=0.12
"Q5": QUAD,k1=28.13592813318368,l=0.12
"Q6": QUAD,k1=-9.424903591282774,l=0.12
"Q7": QUAD,k1=-29.12411828608433,l=0.12
"Q8": QUAD,k1=16.4315775619054,l=0.12
"L0001": LINE=("D10","Q8","D9","Q7","D8","Q6","D7","Q5","D6","Q4","D5","D4","Q3","D3","Q2","D2","Q1","D1","M1")
"BL1": LINE=("L0001")

"""

elegant_file = """

&global_settings
  mpi_io_write_buffer_size = 1048576,
&end

&run_setup
  semaphore_file = run_setup.semaphore,
  centroid = "run_setup.centroid.sdds",
  element_divisions = 100,
  lattice = "elegant.lte",
  output = "run_setup.output.sdds",
  p_central_mev = 58,
  parameters = "run_setup.parameters.sdds",
  sigma = "run_setup.sigma.sdds",
  use_beamline = "BL1",
&end

&run_control
&end

&twiss_output
  alpha_x = -0.30879,
  alpha_y = -5.634,
  beta_x = 2.078,
  beta_y = 8.089,
  filename = "twiss_output.filename.sdds",
  matched = 0,
&end

&bunched_beam
  alpha_x = -0.30879,
  alpha_y = -5.634,
  beta_x = 2.078,
  beta_y = 8.089,
  distribution_cutoff[0] = 3, 3, 3,
  emit_nx = 0.0001887,
  emit_ny = 1.64e-06,
  enforce_rms_values[0] = 1, 1, 1,
  n_particles_per_bunch = 5000,
  sigma_dp = 0.00057,
  sigma_s = 0.002,
&end

&track
&end

"""

with open('elegant.lte', 'w') as f:
    f.write(lattice_file)

with open('elegant.ele', 'w') as f:
    f.write(elegant_file)

import os
os.system('elegant elegant.ele')
